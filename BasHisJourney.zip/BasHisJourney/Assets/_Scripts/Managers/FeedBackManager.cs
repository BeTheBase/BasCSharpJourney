﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FeedBackManager : MonoBehaviour
{
    public GameObject CodersFeedback;
    public AnimationClip Clip;
}
