﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonManagerHandler : MonoBehaviour
{
    public float MoveSpeed = 100f;
    public float RotationAngle = 450f;
}
